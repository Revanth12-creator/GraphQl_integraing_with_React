import React, { Fragment } from 'react';
import './Style.css';
const HomeComponent=()=>{
    return(
        <Fragment>
            {/* <img src="./bag.jpg" alt=""/> */}
            <h1>Component</h1>
        </Fragment>
    )
}
export default HomeComponent;