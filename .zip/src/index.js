import react from 'react';
import ReactDom from "react-dom";
import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap/dist/js/bootstrap.js'
import 'jquery/dist/jquery.js';
import 'popper.js/dist/popper.js';
import App from "./App";


ReactDom.render(<App/>,document.getElementById("root"));